local charge = 0
local target = tonumber(stagehand.settings.get("overdriveTarget", 16)) or 16
target = math.max(4, math.min(64, math.floor(target)))
local midpoint = math.max(1, math.floor(target / 2))

local function updateMeter()
    local shown, detail = stagehand.actions.meter(
        "overdrive",
        charge,
        target,
        "OVERDRIVE")
    if not shown then
        stagehand.log.warn("Overdrive meter was not shown: " .. tostring(detail))
    end
end

local function resetCharge(reason)
    if charge > 0 then
        stagehand.log.info(string.format(
            "Perfect Charge reset from %d because %s.",
            charge,
            tostring(reason)))
    end
    charge = 0
end

stagehand.log.info(string.format(
    "Perfect Charge loaded through Stagehand API %s (target=%d).",
    stagehand.api_version,
    target))

stagehand.events.on("transition.started", function()
    resetCharge("a transition started")
    stagehand.actions.clear_meter("overdrive")
end)

stagehand.events.on("song.changed", function(event)
    resetCharge("the song changed")
    updateMeter()
    stagehand.log.info(string.format(
        "Perfect Charge is tracking song '%s'.",
        tostring(event.song_key)))
end)

stagehand.events.on("music.beat", function(event)
    if event.sequence % 32 == 0 then
        stagehand.log.debug(string.format(
            "Music timing remains active at sequence %d.",
            event.sequence))
    end
end)

stagehand.events.on("combat.perfect_input", function(event)
    charge = charge + 1
    stagehand.log.info(string.format(
        "Perfect Charge %d/%d (input sequence %d).",
        charge,
        target,
        event.sequence))
    updateMeter()

    if charge == midpoint then
        local shown, detail = stagehand.actions.visual_cue("beat-accent")
        if not shown then
            stagehand.log.warn("Midpoint cue was not shown: " .. tostring(detail))
        end
        return
    end

    if charge < target then
        return
    end

    local shown, detail = stagehand.actions.visual_cue("beat-accent")
    if not shown then
        stagehand.log.warn("Overdrive cue was not shown: " .. tostring(detail))
    end

    local overdrives = stagehand.storage.get("overdrives", 0) + 1
    stagehand.storage.set("overdrives", overdrives)
    stagehand.actions.notify(
        string.format(
            "OVERDRIVE READY! %d perfect inputs (activation %d).",
            target,
            overdrives),
        4.0)
    stagehand.log.info("Perfect Charge reached Overdrive.")
    charge = 0
end)

stagehand.events.on("arena.loaded", function()
    resetCharge("the arena loaded")
    updateMeter()
    stagehand.actions.notify(
        string.format(
            "Perfect Charge ready — land %d perfect inputs for Overdrive.",
            target),
        4.0)
end)

return {
    proof = "Perfect Charge uses only Stagehand events and actions, including a namespaced HUD meter."
}
