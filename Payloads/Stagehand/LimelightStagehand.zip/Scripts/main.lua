local UEHelpers = require("UEHelpers")
local Runtime = require("stagehand.runtime")

local MOD_NAME = "LimelightStagehand"
local NOTIFICATION_WIDGET_CLASS =
    "WBP_Collectible_Notification_Main_C"
local BEAT_INDICATOR_WIDGET_CLASS =
    "WBP_BeatIndicator_Main_C"
local HORIZONTAL_FILL_BAR_CLASS =
    "/Game/Pagoda/UI/Game/WBP_HorizontalFillBar.WBP_HorizontalFillBar_C"
local TEXT_BLOCK_CLASS = "/Script/UMG.TextBlock"
local WIDGET_BLUEPRINT_LIBRARY =
    "/Script/UMG.Default__WidgetBlueprintLibrary"
local WIDGET_LAYOUT_LIBRARY =
    "/Script/UMG.Default__WidgetLayoutLibrary"
local MAX_STAGEHAND_METERS = 3

local runtime
local notificationQueue = {}
local notificationBusy = false
local notificationPumpScheduled = false
local notificationEpoch = 0
local notificationRestore = nil
local stagehandVisualCueDepth = 0
local meterWidgets = {}
local meterSlotSequence = 0

local function report(level, message)
    print(string.format(
        "[%s][%s] %s\n",
        MOD_NAME,
        level,
        tostring(message)))
end

local function isValid(object)
    if object == nil then
        return false
    end

    local ok, valid = pcall(function()
        return object:IsValid()
    end)
    return ok and valid == true
end

local function objectName(object)
    if not isValid(object) then
        return "<invalid>"
    end

    local ok, name = pcall(function()
        return object:GetFullName()
    end)
    return ok and tostring(name) or "<unavailable>"
end

local function objectPath(object)
    local name = objectName(object)
    return name:match("%s(/.+)$") or name
end

local function objectToken(object)
    if not isValid(object) then
        return nil
    end

    local ok, address = pcall(function()
        return object:GetAddress()
    end)
    if ok and address ~= nil then
        return tostring(address)
    end

    return objectName(object)
end

local function stableObjectKey(object)
    local name = objectName(object)
    if name == "<invalid>" or name == "<unavailable>" then
        return "unknown"
    end

    local key = name:match("([^%s/.:]+)$") or name
    key = key:gsub("_C$", ""):gsub("[^A-Za-z0-9_.-]", "-")
    return key:sub(1, 96)
end

local function readProperty(object, propertyName)
    if not isValid(object) then
        return nil
    end

    local ok, value = pcall(function()
        return object[propertyName]
    end)
    return ok and value or nil
end

local function parameterValue(parameter)
    if parameter == nil then
        return nil
    end

    local ok, value = pcall(function()
        return parameter:get()
    end)
    return ok and value or parameter
end

local function memberValue(value, memberName)
    if value == nil then
        return nil
    end

    local ok, member = pcall(function()
        return value[memberName]
    end)
    return ok and member or nil
end

local function gameplayTagName(tagParameter)
    local tag = parameterValue(tagParameter)
    local tagName = memberValue(tag, "TagName")
    if tagName == nil then
        return nil
    end

    local ok, value = pcall(function()
        return tagName:ToString()
    end)
    if ok and value ~= nil then
        return tostring(value)
    end

    local fallback = tostring(tagName)
    if fallback == "nil" or fallback == "" then
        return nil
    end
    return fallback
end

local function inputTimingGrade(value)
    local numeric = tonumber(value)
    if numeric == nil and value ~= nil then
        local ok, extracted = pcall(function()
            return value:GetValue()
        end)
        if ok then
            numeric = tonumber(extracted)
        end
    end

    local names = {
        [0] = "OK",
        [1] = "GOOD",
        [2] = "PERFECT"
    }
    if numeric ~= nil then
        numeric = math.floor(numeric)
        return names[numeric] or "UNKNOWN", tostring(numeric)
    end

    local raw = tostring(value or "nil")
        :gsub("[\r\n]", " ")
        :sub(1, 48)
    local lowered = raw:lower()
    if lowered:find("perfect", 1, true) then
        return "PERFECT", raw
    end
    if lowered:find("good", 1, true) then
        return "GOOD", raw
    end
    if lowered:find("ok", 1, true) then
        return "OK", raw
    end
    return "UNKNOWN", raw
end

local function currentWorld()
    local ok, world = pcall(function()
        return UEHelpers.GetWorld()
    end)
    return ok and world or nil
end

local function currentController()
    local ok, controller = pcall(function()
        return UEHelpers.GetPlayerController()
    end)
    return ok and controller or nil
end

local function belongsToCurrentWorld(object)
    local world = currentWorld()
    if not isValid(object) or not isValid(world) then
        return false
    end

    local ok, objectWorld = pcall(function()
        return object:GetWorld()
    end)
    return ok and
        isValid(objectWorld) and
        objectName(objectWorld) == objectName(world)
end

local function playerIndex(controller)
    local player = readProperty(controller, "Player")
    return tonumber(readProperty(player, "ControllerId")) or -1
end

local function isLocalController(controller)
    if not isValid(controller) then
        return false
    end

    local ok, isLocal = pcall(function()
        return controller:IsLocalPlayerController()
    end)
    return ok and isLocal == true
end

local function currentScene()
    local worldName = objectName(currentWorld()):lower()
    if worldName == "<invalid>" or worldName == "<unavailable>" then
        return "unknown"
    end

    if worldName:find("/infinitedisco/", 1, true) then
        return "arena"
    end

    if worldName:find("/startup/", 1, true) or
       worldName:find("/main_menu/", 1, true) then
        return "menu"
    end

    return "story"
end

local function childDirectory(directory, name)
    if type(directory) ~= "table" then
        return nil
    end

    if type(directory[name]) == "table" then
        return directory[name]
    end

    local requested = name:lower()
    for key, value in pairs(directory) do
        if type(key) == "string" and
           type(value) == "table" and
           key:lower() == requested then
            return value
        end
    end
    return nil
end

local function findLogicModsDirectory()
    local ok, directories = pcall(IterateGameDirectories)
    if not ok or type(directories) ~= "table" then
        return nil, "UE4SS could not enumerate the game directories"
    end

    local game = childDirectory(directories, "Game")
    if game == nil then
        for _, candidate in pairs(directories) do
            if type(candidate) == "table" and
               childDirectory(candidate, "Binaries") ~= nil then
                game = candidate
                break
            end
        end
    end

    local binaries = childDirectory(game, "Binaries")
    local win64 = childDirectory(binaries, "Win64")
    local ue4ss = childDirectory(win64, "ue4ss")
    local mods = childDirectory(ue4ss, "Mods") or
        childDirectory(win64, "Mods")
    local stagehand = childDirectory(mods, "LimelightStagehand")
    local logicMods = childDirectory(stagehand, "LogicMods")

    if logicMods == nil then
        return nil, "LimelightStagehand/LogicMods was not found"
    end
    return logicMods
end

local function fileExists(path)
    local file = io.open(path, "rb")
    if file == nil then
        return false
    end
    file:close()
    return true
end

local function readFile(path)
    local file, detail = io.open(path, "rb")
    if file == nil then
        if not fileExists(path) then
            return nil, "not-found"
        end
        return nil, detail
    end

    local contents = file:read("*a")
    file:close()
    return contents
end

local function writeFileAtomic(path, contents)
    local temporaryPath = path .. ".stagehand.tmp"
    local backupPath = path .. ".stagehand.bak"

    os.remove(temporaryPath)
    os.remove(backupPath)

    local file, detail = io.open(temporaryPath, "wb")
    if file == nil then
        return false, detail
    end

    local wrote, writeDetail = file:write(contents)
    local closed, closeDetail = file:close()
    if wrote == nil or closed == nil then
        os.remove(temporaryPath)
        return false, writeDetail or closeDetail
    end

    local hadExisting = fileExists(path)
    if hadExisting then
        local backedUp, backupDetail = os.rename(path, backupPath)
        if not backedUp then
            os.remove(temporaryPath)
            return false, backupDetail
        end
    end

    local replaced, replaceDetail = os.rename(temporaryPath, path)
    if not replaced then
        if hadExisting then
            os.rename(backupPath, path)
        end
        os.remove(temporaryPath)
        return false, replaceDetail
    end

    os.remove(backupPath)
    return true
end

local function appendFile(path, contents)
    local file, detail = io.open(path, "ab")
    if file == nil then
        return false, detail
    end

    local wrote, writeDetail = file:write(contents)
    local closed, closeDetail = file:close()
    if wrote == nil or closed == nil then
        return false, writeDetail or closeDetail
    end
    return true
end

local function logicModDirectories()
    local logicMods, detail = findLogicModsDirectory()
    if logicMods == nil then
        report("WARN", detail)
        return {}
    end

    local result = {}
    for name, directory in pairs(logicMods) do
        if type(name) == "string" and type(directory) == "table" then
            local files = {}
            local disabled = false
            for _, file in pairs(directory.__files or {}) do
                if type(file) == "table" and
                   type(file.__name) == "string" and
                   type(file.__absolute_path) == "string" then
                    if file.__name:lower() == ".stagehand-disabled" then
                        disabled = true
                    end
                    files[#files + 1] = {
                        name = file.__name,
                        path = file.__absolute_path
                    }
                end
            end

            table.sort(files, function(left, right)
                return left.name:lower() < right.name:lower()
            end)

            if disabled then
                report("INFO", "Logic mod disabled by Limelight: " .. name)
            else
                result[#result + 1] = {
                    name = name,
                    path = directory.__absolute_path,
                    files = files
                }
            end
        end
    end
    return result
end

local function stagehandOwnedFile(fileName)
    local logicMods, detail = findLogicModsDirectory()
    if logicMods == nil or type(logicMods.__absolute_path) ~= "string" then
        return nil, detail or "Stagehand root path was not available"
    end

    local stagehandRoot = logicMods.__absolute_path:match(
        "^(.*)[\\/][^\\/]+$")
    if stagehandRoot == nil then
        return nil, "Stagehand root path could not be derived"
    end
    return stagehandRoot .. "\\" .. fileName
end

local function findNotificationLabel(notification)
    local direct = readProperty(notification, "ItemNameLabel")
    if isValid(direct) then
        return direct
    end

    local ok, textBlocks = pcall(function()
        return FindAllOf("CommonTextBlock")
    end)
    if not ok or type(textBlocks) ~= "table" then
        return nil
    end

    local notificationPath = objectPath(notification)
    for _, textBlock in pairs(textBlocks) do
        local path = objectPath(textBlock)
        if isValid(textBlock) and
           notificationPath ~= "<invalid>" and
           notificationPath ~= "<unavailable>" and
           path:sub(1, #notificationPath) == notificationPath and
           path:find("ItemNameLabel", 1, true) then
            return textBlock
        end
    end
    return nil
end

local function findNotificationWidget()
    local ok, widgets = pcall(function()
        return FindAllOf(NOTIFICATION_WIDGET_CLASS)
    end)
    if not ok or type(widgets) ~= "table" then
        return nil, "game-notification-widget-class-not-loaded"
    end

    for _, widget in pairs(widgets) do
        if isValid(widget) and belongsToCurrentWorld(widget) then
            return widget
        end
    end

    return nil, "game-notification-widget-not-ready"
end

local function showVisualCue(cueName)
    if cueName ~= "beat-accent" then
        return false, "unsupported-visual-cue"
    end

    local ok, widgets = pcall(function()
        return FindAllOf(BEAT_INDICATOR_WIDGET_CLASS)
    end)
    if not ok or type(widgets) ~= "table" then
        return false, "beat-indicator-class-not-loaded"
    end

    for _, widget in pairs(widgets) do
        if isValid(widget) and belongsToCurrentWorld(widget) then
            stagehandVisualCueDepth = stagehandVisualCueDepth + 1
            local shown, detail = pcall(function()
                widget:HandlePerfectInput()
            end)
            stagehandVisualCueDepth = math.max(
                0,
                stagehandVisualCueDepth - 1)
            return shown,
                shown and "hud-beat-accent" or tostring(detail)
        end
    end

    return false, "beat-indicator-not-ready"
end

local function showGameNotification(item)
    local widget, widgetDetail = findNotificationWidget()
    if widget == nil then
        return false, widgetDetail
    end

    local notification = readProperty(
        widget,
        "WBP_Collectible_Notification")
    local textBlock = readProperty(notification, "ItemNameText")
    local labelBlock = findNotificationLabel(notification)
    local animation = readProperty(widget, "AnimShowNotification")
    local textLibraryOk, textLibrary = pcall(function()
        return UEHelpers.GetKismetTextLibrary()
    end)

    if not isValid(notification) or
       not isValid(textBlock) or
       not isValid(animation) or
       not textLibraryOk or
       not isValid(textLibrary) then
        return false, "game-notification-widget-incomplete"
    end

    local originalLabel = nil
    if isValid(labelBlock) then
        pcall(function()
            originalLabel = labelBlock:GetText()
        end)
    end

    local shown, showDetail = pcall(function()
        if isValid(labelBlock) then
            labelBlock:SetText(textLibrary:Conv_StringToText("STAGEHAND:"))
        end
        textBlock:SetText(textLibrary:Conv_StringToText(item.message))

        pcall(function()
            widget:StopAnimation(animation)
        end)
        widget:PlayAnimation(
            animation,
            0.0,
            1,
            0,
            1.0,
            false)
    end)

    local restore = function()
        if isValid(labelBlock) and originalLabel ~= nil then
            pcall(function()
                labelBlock:SetText(originalLabel)
            end)
        end
    end

    local backend = isValid(labelBlock) and
        "game-hud-stagehand-label" or
        "game-hud-item-only"
    return shown,
        shown and backend or tostring(showDetail),
        shown and restore or nil
end

local function emitDebugNotification(item)
    local world = currentWorld()
    local ok, systemLibrary = pcall(function()
        return UEHelpers.GetKismetSystemLibrary()
    end)
    if not isValid(world) or not ok or not isValid(systemLibrary) then
        return false
    end

    return pcall(function()
        systemLibrary:PrintString(
            world,
            string.format(
                "[STAGEHAND] %s: %s",
                item.modName,
                item.message),
            true,
            false,
            { R = 0.35, G = 0.90, B = 1.00, A = 1.00 },
            item.duration,
            UEHelpers.FindOrAddFName(
                "LimelightStagehand." .. item.modId))
    end)
end

local pumpNotifications

local function scheduleNotificationPump(delay)
    if notificationPumpScheduled then
        return
    end

    notificationPumpScheduled = true
    local expectedEpoch = notificationEpoch
    ExecuteInGameThreadWithDelay(delay, function()
        if notificationEpoch ~= expectedEpoch then
            return
        end

        notificationPumpScheduled = false
        pumpNotifications()
    end)
end

local function resetNotifications()
    if notificationRestore ~= nil then
        pcall(notificationRestore)
        notificationRestore = nil
    end
    notificationEpoch = notificationEpoch + 1
    notificationQueue = {}
    notificationBusy = false
    notificationPumpScheduled = false
end

pumpNotifications = function()
    if notificationBusy then
        return
    end

    while #notificationQueue > 0 do
        local item = notificationQueue[1]
        local state = runtime and runtime:get_state() or nil
        if state == nil or
           state.transitioning or
           state.generation ~= item.generation then
            table.remove(notificationQueue, 1)
        else
            local shown, detail, restore = showGameNotification(item)
            if shown then
                table.remove(notificationQueue, 1)
                notificationBusy = true
                notificationRestore = restore
                report("NOTIFY", string.format(
                    "shown backend=%s mod=%s generation=%d",
                    tostring(detail),
                    item.modId,
                    item.generation))

                local expectedEpoch = notificationEpoch
                notificationPumpScheduled = true
                ExecuteInGameThreadWithDelay(
                    math.floor(item.duration * 1000),
                    function()
                        if notificationEpoch ~= expectedEpoch then
                            return
                        end

                        notificationBusy = false
                        if notificationRestore ~= nil then
                            pcall(notificationRestore)
                            notificationRestore = nil
                        end
                        notificationPumpScheduled = false
                        pumpNotifications()
                    end)
                return
            end

            item.attempts = item.attempts + 1
            if item.attempts == 1 then
                -- PrintString remains useful in non-Shipping builds, but it is
                -- diagnostic-only here because Shipping builds silently drop it.
                emitDebugNotification(item)
            end

            if item.attempts < 5 then
                local retryDelays = { 200, 500, 1000, 2000 }
                scheduleNotificationPump(
                    retryDelays[item.attempts] or 2000)
                return
            end

            table.remove(notificationQueue, 1)
            report("WARN", string.format(
                "notification_not_shown mod=%s generation=%d detail=%s",
                item.modId,
                item.generation,
                tostring(detail)))
        end
    end
end

local function meterKey(modId, meterId)
    return tostring(modId) .. ":" .. tostring(meterId)
end

local function removeMeterEntry(key)
    local entry = meterWidgets[key]
    if entry == nil then
        return false
    end

    local widget = entry.widget
    if isValid(widget) then
        local removed = pcall(function()
            widget:RemoveFromParent()
        end)
        if not removed then
            pcall(function()
                widget:RemoveFromViewport()
            end)
        end
    end
    meterWidgets[key] = nil
    return true
end

local function resetMeters()
    local keys = {}
    for key in pairs(meterWidgets) do
        keys[#keys + 1] = key
    end
    for _, key in ipairs(keys) do
        removeMeterEntry(key)
    end
    meterSlotSequence = 0
end

local function meterCount()
    local count = 0
    for _ in pairs(meterWidgets) do
        count = count + 1
    end
    return count
end

local function modMeterCount(modId)
    local count = 0
    for _, entry in pairs(meterWidgets) do
        if entry.modId == modId then
            count = count + 1
        end
    end
    return count
end

local function findStaticObject(path)
    local ok, object = pcall(function()
        return StaticFindObject(path)
    end)
    return ok and isValid(object) and object or nil
end

local function viewportDimensions(world, layoutLibrary)
    local ok, size = pcall(function()
        return layoutLibrary:GetViewportSize(world)
    end)
    local width = ok and tonumber(memberValue(size, "X")) or nil
    local height = ok and tonumber(memberValue(size, "Y")) or nil
    if width == nil or width <= 0 or height == nil or height <= 0 then
        return 1920, 1080
    end
    return width, height
end

local function meterFillColor(progress)
    if progress >= 1.0 then
        return { R = 0.00, G = 0.72, B = 1.00, A = 1.00 }
    end
    return { R = 1.00, G = 0.28, B = 0.82, A = 1.00 }
end

local function meterNumber(value)
    local rounded = math.floor(value + 0.5)
    if math.abs(value - rounded) < 0.001 then
        return tostring(rounded)
    end
    return string.format("%.1f", value)
end

local function meterLabelText(label, value, maximum, progress)
    local ready = progress >= 1.0 and " READY" or ""
    return string.format(
        "%s%s  %s/%s",
        label,
        ready,
        meterNumber(math.max(0.0, math.min(value, maximum))),
        meterNumber(maximum))
end

local function createMeterLabel(widget, meterWidth)
    local widgetTree = readProperty(widget, "WidgetTree")
    local rootWidget = readProperty(widgetTree, "RootWidget")
    local textBlockClass = findStaticObject(TEXT_BLOCK_CLASS)
    if not isValid(widgetTree) or
       not isValid(rootWidget) or
       textBlockClass == nil then
        return nil, "horizontal-fill-bar-label-support-not-ready"
    end

    local created, label = pcall(function()
        return StaticConstructObject(
            textBlockClass,
            widgetTree,
            0,
            0,
            0,
            nil,
            false,
            false,
            nil)
    end)
    if not created or not isValid(label) then
        return nil, created and
            "horizontal-fill-bar-label-create-returned-invalid" or
            tostring(label)
    end

    local added, detail = pcall(function()
        rootWidget:AddChildToOverlay(label)
        label:SetMinDesiredWidth(math.max(1.0, meterWidth - 24.0))
        label:SetRenderTranslation({ X = 12.0, Y = -1.0 })
        label:SetShadowOffset({ X = 2.0, Y = 2.0 })
        label:SetShadowColorAndOpacity(
            { R = 0.01, G = 0.01, B = 0.06, A = 1.00 })
        label:SetColorAndOpacity({
            SpecifiedColor = { R = 1.00, G = 1.00, B = 1.00, A = 1.00 },
            ColorUseRule = 0
        })

        pcall(function()
            local font = readProperty(label, "Font")
            font.Size = 18.0
            local outline = memberValue(font, "OutlineSettings")
            outline.OutlineSize = 2
            outline.OutlineColor =
                { R = 0.01, G = 0.01, B = 0.06, A = 1.00 }
            label:SetFont(font)
        end)
    end)
    if not added then
        return nil, tostring(detail)
    end

    return label, "game-horizontal-fill-bar-label"
end

local function styleMeterWidget(widget, labelWidget, progress, text)
    local fillImage = readProperty(widget, "FillImage")
    local drainImage = readProperty(widget, "DrainImage")
    if not isValid(fillImage) or
       not isValid(drainImage) then
        return false, "horizontal-fill-bar-incomplete"
    end

    local styled, detail = pcall(function()
        fillImage:SetColorAndOpacity(meterFillColor(progress))
        fillImage:SetRenderOpacity(1.0)
        drainImage:SetColorAndOpacity(
            { R = 0.08, G = 0.05, B = 0.22, A = 1.00 })
        drainImage:SetRenderOpacity(0.82)
        widget:SetDrainDirectNoTimer(1.0)
        widget:SetFillDirectNoTimer(progress)

        if isValid(labelWidget) then
            local textLibrary = UEHelpers.GetKismetTextLibrary()
            labelWidget:SetText(textLibrary:Conv_StringToText(text))
        end
    end)
    return styled, styled and "styled" or tostring(detail)
end

local function createMeterEntry(modId, meterId, generation)
    if meterCount() >= MAX_STAGEHAND_METERS then
        return nil, "global-meter-limit-reached"
    end
    if modMeterCount(modId) >= 1 then
        return nil, "mod-meter-limit-reached"
    end

    local world = currentWorld()
    local controller = currentController()
    local widgetClass = findStaticObject(HORIZONTAL_FILL_BAR_CLASS)
    local widgetLibrary = findStaticObject(WIDGET_BLUEPRINT_LIBRARY)
    local layoutLibrary = findStaticObject(WIDGET_LAYOUT_LIBRARY)
    if not isValid(world) or
       not isValid(controller) or
       widgetClass == nil or
       widgetLibrary == nil or
       layoutLibrary == nil then
        return nil, "horizontal-fill-bar-support-not-ready"
    end

    local created, widget = pcall(function()
        return widgetLibrary:Create(world, widgetClass, controller)
    end)
    if not created or not isValid(widget) then
        return nil, created and
            "horizontal-fill-bar-create-returned-invalid" or
            tostring(widget)
    end

    meterSlotSequence = meterSlotSequence + 1
    local width, height = viewportDimensions(world, layoutLibrary)
    local meterWidth = math.max(280, math.min(480, width * 0.20))
    local meterHeight = math.max(24, math.min(34, height * 0.027))
    local position = {
        X = width * 0.025,
        Y = height * (0.335 + ((meterSlotSequence - 1) * 0.042))
    }

    local labelWidget, labelDetail = createMeterLabel(widget, meterWidth)
    if labelWidget == nil then
        report("WARN", string.format(
            "HUD meter label unavailable mod=%s meter=%s detail=%s",
            tostring(modId),
            tostring(meterId),
            tostring(labelDetail)))
    end

    local prepared, detail = pcall(function()
        widget:SetAlignmentInViewport({ X = 0.0, Y = 0.0 })
        widget:SetDesiredSizeInViewport({ X = meterWidth, Y = meterHeight })
        widget:SetPositionInViewport(position, true)
        widget:AddToViewport(80 + meterSlotSequence)
    end)
    if not prepared then
        pcall(function()
            widget:RemoveFromParent()
        end)
        return nil, tostring(detail)
    end

    local backend = labelWidget ~= nil and
        "game-horizontal-fill-bar-labelled" or
        "game-horizontal-fill-bar-unlabelled"
    local entry = {
        widget = widget,
        labelWidget = labelWidget,
        backend = backend,
        modId = modId,
        meterId = meterId,
        generation = generation,
        slot = meterSlotSequence
    }
    meterWidgets[meterKey(modId, meterId)] = entry
    return entry, backend
end

local function showMeter(modId, meterId, value, maximum, label, state)
    if state.transitioning or not state.ready then
        return false, state.transitioning and
            "transition-in-progress" or
            "game-not-ready"
    end
    if state.scene ~= "arena" then
        return false, "hud-meter-arena-only"
    end

    local key = meterKey(modId, meterId)
    local entry = meterWidgets[key]
    if entry ~= nil and
       (entry.generation ~= state.generation or not isValid(entry.widget)) then
        removeMeterEntry(key)
        entry = nil
    end

    local backend = entry ~= nil and entry.backend or
        "game-horizontal-fill-bar"
    if entry == nil then
        entry, backend = createMeterEntry(
            modId,
            meterId,
            state.generation)
        if entry == nil then
            return false, backend
        end
    end

    local progress = math.max(0.0, math.min(1.0, value / maximum))
    local styled, detail = styleMeterWidget(
        entry.widget,
        entry.labelWidget,
        progress,
        meterLabelText(label, value, maximum, progress))
    if not styled then
        removeMeterEntry(key)
        return false, detail
    end

    report("ACTION", string.format(
        "meter=%s mod=%s generation=%d value=%.3f maximum=%.3f progress=%.3f backend=%s",
        tostring(meterId),
        tostring(modId),
        tonumber(state.generation) or -1,
        value,
        maximum,
        progress,
        tostring(backend)))
    return true, backend
end

local host = {
    print = function(message)
        report("RUNTIME", message)
    end,
    now = function()
        return os.date("!%Y-%m-%dT%H:%M:%SZ")
    end,
    read_file = readFile,
    write_file_atomic = writeFileAtomic,
    append_file = appendFile,
    load_file = function(path, environment)
        return loadfile(path, "t", environment)
    end,
    list_logic_mod_directories = logicModDirectories,
    data_file = function(mod, fileName)
        return mod.directory .. "\\" .. fileName
    end,
    write_health_report = function(contents)
        local path, detail = stagehandOwnedFile("stagehand-health.json")
        if path == nil then
            return false, detail
        end
        return writeFileAtomic(path, contents)
    end,
    notify = function(modId, modName, message, duration, state)
        if state.transitioning or not state.ready then
            return false, state.transitioning and
                "transition-in-progress" or
                "game-not-ready"
        end

        if not isValid(currentWorld()) then
            return false, "game-world-not-ready"
        end

        notificationQueue[#notificationQueue + 1] = {
            modId = modId,
            modName = modName,
            message = message,
            duration = duration,
            generation = state.generation,
            attempts = 0
        }
        pumpNotifications()
        return true, "queued-for-game-hud"
    end,
    visual_cue = function(modId, cueName, state)
        if state.transitioning or not state.ready then
            return false, state.transitioning and
                "transition-in-progress" or
                "game-not-ready"
        end

        if not isValid(currentWorld()) then
            return false, "game-world-not-ready"
        end

        local shown, detail = showVisualCue(cueName)
        if shown then
            report("ACTION", string.format(
                "visual_cue=%s mod=%s generation=%d backend=%s",
                tostring(cueName),
                tostring(modId),
                tonumber(state.generation) or -1,
                tostring(detail)))
        end
        return shown, detail
    end,
    meter = function(modId, meterId, value, maximum, label, state)
        return showMeter(modId, meterId, value, maximum, label, state)
    end,
    clear_meter = function(modId, meterId)
        local removed = removeMeterEntry(meterKey(modId, meterId))
        return true, removed and "removed" or "already-clear"
    end
}

runtime = Runtime.new(host)
local discoveryOk, discoveryDetail = pcall(function()
    runtime:load_all()
end)
if not discoveryOk then
    report("ERROR", "Logic-mod discovery failed: " .. tostring(discoveryDetail))
end

local function scheduleReadyProbe(reason, delays)
    local expectedGeneration = runtime:get_state().generation

    for _, delay in ipairs(delays or { 250, 750, 1500, 3000 }) do
        ExecuteInGameThreadWithDelay(delay, function()
            local state = runtime:get_state()
            if state.generation ~= expectedGeneration or state.transitioning then
                return
            end

            local world = currentWorld()
            local controller = currentController()
            local pawn = readProperty(controller, "Pawn")

            if not isValid(world) or
               not isValid(controller) or
               not isValid(pawn) or
               not belongsToCurrentWorld(controller) or
               not belongsToCurrentWorld(pawn) then
                return
            end

            runtime:mark_player_spawned(
                objectToken(pawn),
                playerIndex(controller),
                isLocalController(controller))

            if runtime:mark_game_ready(currentScene()) then
                report("LIFECYCLE", string.format(
                    "game_ready reason=%s generation=%d scene=%s",
                    tostring(reason),
                    expectedGeneration,
                    currentScene()))
            end
        end)
    end
end

local NATIVE_SONG_HOOK =
    "/Script/Pagoda.PagodaLevelFlowSubsystem:OnSongStarted"
local ARENA_SONG_HOOK =
    "/Game/Pagoda/Characters/Player/BP_PagodaPlayerController.BP_PagodaPlayerController_C:OnSongStarted"
local PERFECT_INPUT_HOOK =
    "/Game/Pagoda/UI/Game/BeatIndicator/WBP_BeatIndicator_Main.WBP_BeatIndicator_Main_C:HandlePerfectInput"
local INPUT_GRADE_PROBE_HOOK =
    "/Script/Pagoda.PagodaInputBufferSubsystem:OnAbilityActivatedWithInput__DelegateSignature"
local INPUT_GRADE_PARAM_PROBE_HOOK =
    "/Script/Pagoda.PagodaCombatFunctionLibrary:AddOrUpdateInputTimingGradeParam"
local INPUT_GRADE_RETURN_PROBE_HOOK =
    "/Script/Pagoda.PagodaInputBufferSubsystem:GetInputTimingGradeForAction"
local ABILITY_INPUT_GRADE_RETURN_PROBE_HOOK =
    "/Script/Pagoda.PagodaGameplayAbility:GetActivateInputTimingGrade"
local HIT_WORD_CUE_SETTINGS =
    "/Script/Pagoda.Default__PagodaCombatSettings"
local HIT_WORD_ASSET_BURST_HOOK =
    "/Script/Pagoda.PagodaGameplayCue_Burst:OnBurst"
local HIT_WORD_CUE_HOOKS = {
    {
        source = "pagoda-local",
        path = "/Script/Pagoda.PagodaAbilitySystemComponent:ExecuteGameplayCueLocal",
        tagIndex = 1
    },
    {
        source = "multicast-params",
        path = "/Script/GameplayAbilities.AbilitySystemComponent:NetMulticast_InvokeGameplayCueExecuted_WithParams",
        tagIndex = 1
    },
    {
        source = "multicast-context",
        path = "/Script/GameplayAbilities.AbilitySystemComponent:NetMulticast_InvokeGameplayCueExecuted",
        tagIndex = 1
    },
    {
        source = "function-library",
        path = "/Script/GameplayAbilities.GameplayCueFunctionLibrary:ExecuteGameplayCueOnActor",
        targetIndex = 1,
        tagIndex = 2
    }
}
local NATIVE_BEAT_HOOKS = {
    {
        source = "beat-indicator",
        path = "/Script/Pagoda.PagodaBeatIndicatorWidget:HandleBeatEvent"
    },
    {
        source = "attack-pattern",
        path = "/Script/Pagoda.PagodaAttackPatternSubsystem:HandleBeatEvent"
    },
    {
        source = "song-player",
        path = "/Script/Pagoda.PagodaSongPlayer:HandleBeatEvent"
    }
}

local songHooks = {
    native = false,
    arena = false
}
local arenaSongHookScheduleGeneration = nil
local perfectInputHookRegistered = false
local perfectInputHookScheduleGeneration = nil
local firstPerfectInputReportedGeneration = nil
local inputGradeProbeSeen = {}
local hitWordCueProbeSeen = {}
local hitWordAssetProbeSeen = {}
local hitWordCueGrades = nil
local writeRuntimeHealth = nil

local function handleSongStarted(source, contextParameter, songParameter)
    local context = parameterValue(contextParameter)
    local song = parameterValue(songParameter)

    if not isValid(song) or not isValid(currentWorld()) then
        return
    end

    if source == "arena-controller" and
       (not isValid(context) or
        not isLocalController(context) or
        not belongsToCurrentWorld(context)) then
        return
    end

    local expectedGeneration = runtime:get_state().generation
    local songToken = objectToken(song)
    local songKey = stableObjectKey(song)
    local delivered = false

    for _, delay in ipairs({ 0, 100, 300, 750, 1500, 3000 }) do
        ExecuteInGameThreadWithDelay(delay, function()
            if delivered then
                return
            end

            local state = runtime:get_state()
            if state.generation ~= expectedGeneration or state.transitioning then
                return
            end

            if runtime:mark_song_changed(songToken, songKey) then
                delivered = true
                report("LIFECYCLE", string.format(
                    "song_changed source=%s generation=%d songKey=%s",
                    source,
                    expectedGeneration,
                    songKey))
            end
        end)
    end
end

local function registerSongHook(kind, path, source)
    if songHooks[kind] then
        return true
    end

    local registered, preId, postId = pcall(function()
        return RegisterHook(path, function(contextParameter, songParameter)
            handleSongStarted(source, contextParameter, songParameter)
        end)
    end)

    if not registered then
        return false, preId
    end

    songHooks[kind] = true
    report("HOOKS", string.format(
        "registered songSource=%s pre=%s post=%s",
        source,
        tostring(preId),
        tostring(postId)))
    if writeRuntimeHealth ~= nil then
        writeRuntimeHealth("song-hook-" .. source)
    end
    return true
end

local function scheduleArenaSongHookRegistration(reason)
    if songHooks.arena or currentScene() ~= "arena" then
        return
    end

    local expectedGeneration = runtime:get_state().generation
    if arenaSongHookScheduleGeneration == expectedGeneration then
        return
    end
    arenaSongHookScheduleGeneration = expectedGeneration

    local delays = { 250, 750, 1500, 3000 }
    for index, delay in ipairs(delays) do
        ExecuteInGameThreadWithDelay(delay, function()
            local state = runtime:get_state()
            if songHooks.arena or
               state.generation ~= expectedGeneration or
               state.transitioning or
               currentScene() ~= "arena" then
                return
            end

            local registered, detail = registerSongHook(
                "arena",
                ARENA_SONG_HOOK,
                "arena-controller")
            if not registered and
               index == #delays and
               not songHooks.native then
                report("WARN", string.format(
                    "Arena song hook unavailable after %s: %s",
                    tostring(reason),
                    tostring(detail)))
            end
        end)
    end
end

local function registerPerfectInputHook()
    if perfectInputHookRegistered then
        return true
    end

    local registered, preId, postId = pcall(function()
        return RegisterHook(
            PERFECT_INPUT_HOOK,
            function(widgetParameter)
                if stagehandVisualCueDepth > 0 then
                    return
                end

                local widget = parameterValue(widgetParameter)
                if not isValid(widget) or not belongsToCurrentWorld(widget) then
                    return
                end

                if runtime:mark_combat_perfect_input(
                    playerIndex(currentController())) then
                    local generation = runtime:get_state().generation
                    if firstPerfectInputReportedGeneration ~= generation then
                        firstPerfectInputReportedGeneration = generation
                        report("LIFECYCLE", string.format(
                            "combat_perfect_input_active generation=%d source=beat-indicator",
                            generation))
                    end
                end
            end)
    end)

    if not registered then
        return false, preId
    end

    perfectInputHookRegistered = true
    report("HOOKS", string.format(
        "registered perfectInputSource=beat-indicator pre=%s post=%s",
        tostring(preId),
        tostring(postId)))
    if writeRuntimeHealth ~= nil then
        writeRuntimeHealth("perfect-input-hook")
    end
    return true
end

local function schedulePerfectInputHookRegistration(reason)
    if perfectInputHookRegistered or currentScene() ~= "arena" then
        return
    end

    local expectedGeneration = runtime:get_state().generation
    if perfectInputHookScheduleGeneration == expectedGeneration then
        return
    end
    perfectInputHookScheduleGeneration = expectedGeneration

    local delays = { 250, 750, 1500, 3000 }
    for index, delay in ipairs(delays) do
        ExecuteInGameThreadWithDelay(delay, function()
            local state = runtime:get_state()
            if perfectInputHookRegistered or
               state.generation ~= expectedGeneration or
               state.transitioning or
               currentScene() ~= "arena" then
                return
            end

            local registered, detail = registerPerfectInputHook()
            if not registered and index == #delays then
                report("WARN", string.format(
                    "Perfect-input adapter unavailable after %s: %s",
                    tostring(reason),
                    tostring(detail)))
            end
        end)
    end
end

local nativeSongHookOk, nativeSongHookDetail = registerSongHook(
    "native",
    NATIVE_SONG_HOOK,
    "level-flow")
if not nativeSongHookOk then
    report("WARN", string.format(
        "Native song hook unavailable; arena fallback will be retried after load: %s",
        tostring(nativeSongHookDetail)))
end

local function observeInputGradeProbe(
    source,
    contextParameter,
    abilityClassParameter,
    inputActionParameter,
    gradeParameter)
    local state = runtime:get_state()
    local controller = currentController()
    if state.transitioning or
       not state.ready or
       state.scene ~= "arena" or
       not isValid(controller) or
       not isLocalController(controller) then
        return
    end

    local grade, rawGrade = inputTimingGrade(parameterValue(gradeParameter))
    local seenKey = grade == "UNKNOWN" and
        grade .. ":" .. rawGrade or
        grade
    if inputGradeProbeSeen[seenKey] then
        return
    end
    inputGradeProbeSeen[seenKey] = true

    local context = parameterValue(contextParameter)
    local abilityClass = parameterValue(abilityClassParameter)
    local inputAction = parameterValue(inputActionParameter)
    report("PROBE", string.format(
        "input_grade source=%s generation=%d grade=%s raw=%s context=%s ability=%s action=%s",
        tostring(source),
        state.generation,
        grade,
        rawGrade,
        stableObjectKey(context),
        stableObjectKey(abilityClass),
        stableObjectKey(inputAction)))

    local queued, detail = host.notify(
        "stagehand.input-grade-probe",
        "Stagehand Input Probe",
        string.format(
            "INPUT GRADE PROBE: %s timing detected (raw %s).",
            grade,
            rawGrade),
        3.5,
        state)
    if not queued then
        report("WARN", "Input-grade probe notification failed: " .. tostring(detail))
    end
end

local function handleInputGradeDelegateProbe(
    contextParameter,
    abilityClassParameter,
    inputActionParameter,
    gradeParameter)
    observeInputGradeProbe(
        "input-buffer-delegate",
        contextParameter,
        abilityClassParameter,
        inputActionParameter,
        gradeParameter)
end

local function handleInputGradeParamProbe(
    contextParameter,
    inputParamsParameter,
    gradeParameter)
    observeInputGradeProbe(
        "combat-parameter",
        contextParameter,
        inputParamsParameter,
        nil,
        gradeParameter)
end

local function handleInputGradeReturnProbe(
    contextParameter,
    gradeParameter,
    inputActionParameter)
    observeInputGradeProbe(
        "input-buffer-return",
        contextParameter,
        nil,
        inputActionParameter,
        gradeParameter)
end

local inputGradeProbeOk, inputGradeProbePreId, inputGradeProbePostId =
    pcall(function()
        return RegisterHook(
            INPUT_GRADE_PROBE_HOOK,
            handleInputGradeDelegateProbe)
    end)

if inputGradeProbeOk then
    report("HOOKS", string.format(
        "registered inputGradeProbeSource=input-buffer pre=%s post=%s",
        tostring(inputGradeProbePreId),
        tostring(inputGradeProbePostId)))
else
    report("WARN", string.format(
        "Input-grade probe unavailable; no public API was affected: %s",
        tostring(inputGradeProbePreId)))
end


local inputGradeParamProbeOk,
    inputGradeParamProbePreId,
    inputGradeParamProbePostId = pcall(function()
        return RegisterHook(
            INPUT_GRADE_PARAM_PROBE_HOOK,
            handleInputGradeParamProbe)
    end)

if inputGradeParamProbeOk then
    report("HOOKS", string.format(
        "registered inputGradeProbeSource=combat-parameter pre=%s post=%s",
        tostring(inputGradeParamProbePreId),
        tostring(inputGradeParamProbePostId)))
else
    report("WARN", string.format(
        "Combat-parameter grade probe unavailable; no public API was affected: %s",
        tostring(inputGradeParamProbePreId)))
end

local inputGradeReturnProbeOk,
    inputGradeReturnProbePreId,
    inputGradeReturnProbePostId = pcall(function()
        return RegisterHook(
            INPUT_GRADE_RETURN_PROBE_HOOK,
            function() end,
            handleInputGradeReturnProbe)
    end)

if inputGradeReturnProbeOk then
    report("HOOKS", string.format(
        "registered inputGradeProbeSource=input-buffer-return pre=%s post=%s",
        tostring(inputGradeReturnProbePreId),
        tostring(inputGradeReturnProbePostId)))
else
    report("WARN", string.format(
        "Input-buffer return-grade probe unavailable; no public API was affected: %s",
        tostring(inputGradeReturnProbePreId)))
end

local abilityInputGradeReturnProbeOk,
    abilityInputGradeReturnProbePreId,
    abilityInputGradeReturnProbePostId = pcall(function()
        return RegisterHook(
            ABILITY_INPUT_GRADE_RETURN_PROBE_HOOK,
            function() end,
            function(contextParameter, gradeParameter)
                observeInputGradeProbe(
                    "gameplay-ability-return",
                    contextParameter,
                    nil,
                    nil,
                    gradeParameter)
            end)
    end)

if abilityInputGradeReturnProbeOk then
    report("HOOKS", string.format(
        "registered inputGradeProbeSource=gameplay-ability-return pre=%s post=%s",
        tostring(abilityInputGradeReturnProbePreId),
        tostring(abilityInputGradeReturnProbePostId)))
else
    report("WARN", string.format(
        "Gameplay-ability return-grade probe unavailable; no public API was affected: %s",
        tostring(abilityInputGradeReturnProbePreId)))
end

local function resolveHitWordCueGrades()
    if hitWordCueGrades ~= nil then
        return hitWordCueGrades
    end

    local ok, settings = pcall(function()
        return StaticFindObject(HIT_WORD_CUE_SETTINGS)
    end)
    if not ok or not isValid(settings) then
        return nil
    end

    local goodTag = gameplayTagName(
        readProperty(settings, "GoodInputHitWordCueTag"))
    local perfectTag = gameplayTagName(
        readProperty(settings, "PerfectInputHitWordCueTag"))
    if goodTag == nil or perfectTag == nil then
        return nil
    end

    hitWordCueGrades = {
        [goodTag] = {
            internal = "GOOD",
            player = "BEAT"
        },
        [perfectTag] = {
            internal = "PERFECT",
            player = "PERFECT"
        }
    }
    report("PROBE", string.format(
        "hit_word_tags resolved good=%s perfect=%s",
        goodTag,
        perfectTag))
    return hitWordCueGrades
end

local function handleHitWordCueProbe(
    source,
    contextParameter,
    targetParameter,
    tagParameter)
    local state = runtime:get_state()
    local controller = currentController()
    if state.transitioning or
       not state.ready or
       state.scene ~= "arena" or
       not isValid(controller) or
       not isLocalController(controller) then
        return
    end

    local context = parameterValue(contextParameter)
    local target = parameterValue(targetParameter)
    local worldObject = isValid(target) and target or context
    if not isValid(worldObject) or not belongsToCurrentWorld(worldObject) then
        return
    end

    local tag = gameplayTagName(tagParameter)
    local grades = resolveHitWordCueGrades()
    local grade = grades ~= nil and grades[tag] or nil
    if grade == nil or hitWordCueProbeSeen[grade.internal] then
        return
    end
    hitWordCueProbeSeen[grade.internal] = true

    report("PROBE", string.format(
        "hit_word_cue source=%s generation=%d internal=%s player=%s tag=%s target=%s",
        tostring(source),
        state.generation,
        grade.internal,
        grade.player,
        tostring(tag),
        stableObjectKey(worldObject)))

    local queued, detail = host.notify(
        "stagehand.hit-word-cue-probe",
        "Stagehand Hit Word Probe",
        string.format(
            "HIT-WORD CUE PROBE: game %s = internal %s (%s).",
            grade.player,
            grade.internal,
            tostring(source)),
        4.5,
        state)
    if not queued then
        report("WARN", "Hit-word cue probe notification failed: " .. tostring(detail))
    end
end

local registeredHitWordCueHookCount = 0
for _, hook in ipairs(HIT_WORD_CUE_HOOKS) do
    local spec = hook
    local registered, preId, postId = pcall(function()
        return RegisterHook(
            spec.path,
            function(contextParameter, ...)
                local parameters = { ... }
                handleHitWordCueProbe(
                    spec.source,
                    contextParameter,
                    spec.targetIndex ~= nil and
                        parameters[spec.targetIndex] or nil,
                    parameters[spec.tagIndex])
            end)
    end)

    if registered then
        registeredHitWordCueHookCount = registeredHitWordCueHookCount + 1
        report("HOOKS", string.format(
            "registered hitWordCueProbeSource=%s pre=%s post=%s",
            spec.source,
            tostring(preId),
            tostring(postId)))
    else
        report("WARN", string.format(
            "Hit-word cue probe unavailable source=%s detail=%s",
            spec.source,
            tostring(preId)))
    end
end

local function handleHitWordAssetProbe(contextParameter, targetParameter)
    local state = runtime:get_state()
    local controller = currentController()
    if state.transitioning or
       not state.ready or
       state.scene ~= "arena" or
       not isValid(controller) or
       not isLocalController(controller) then
        return
    end

    local cue = parameterValue(contextParameter)
    local cueName = objectName(cue)
    local grade = nil
    if cueName:find("GC_InputTimingWord_Good", 1, true) then
        grade = {
            internal = "GOOD",
            possiblePlayerLabel = "BEAT"
        }
    elseif cueName:find("GC_InputTimingWord_Perfect", 1, true) then
        grade = {
            internal = "PERFECT",
            possiblePlayerLabel = "PERFECT"
        }
    end

    if grade == nil or hitWordAssetProbeSeen[grade.internal] then
        return
    end

    local target = parameterValue(targetParameter)
    if not isValid(target) or not belongsToCurrentWorld(target) then
        return
    end

    hitWordAssetProbeSeen[grade.internal] = true
    report("PROBE", string.format(
        "hit_word_asset source=burst generation=%d internal=%s possiblePlayerLabel=%s cue=%s target=%s",
        state.generation,
        grade.internal,
        grade.possiblePlayerLabel,
        stableObjectKey(cue),
        stableObjectKey(target)))

    local queued, detail = host.notify(
        "stagehand.hit-word-asset-probe",
        "Stagehand Direct Hit Word Probe",
        string.format(
            "DIRECT HIT-WORD PROBE: %s asset fired (game may display %s).",
            grade.internal,
            grade.possiblePlayerLabel),
        4.5,
        state)
    if not queued then
        report("WARN", "Direct hit-word probe notification failed: " .. tostring(detail))
    end
end

local hitWordAssetProbeOk,
    hitWordAssetProbePreId,
    hitWordAssetProbePostId = pcall(function()
        return RegisterHook(
            HIT_WORD_ASSET_BURST_HOOK,
            handleHitWordAssetProbe)
    end)

if hitWordAssetProbeOk then
    report("HOOKS", string.format(
        "registered hitWordAssetProbeSource=burst pre=%s post=%s",
        tostring(hitWordAssetProbePreId),
        tostring(hitWordAssetProbePostId)))
else
    report("WARN", string.format(
        "Direct hit-word asset probe unavailable; no public API was affected: %s",
        tostring(hitWordAssetProbePreId)))
end

local activeBeatSource = nil
local activeBeatSourceGeneration = nil

local function handleMusicBeat(source, contextParameter, barParameter, beatParameter)
    local context = parameterValue(contextParameter)
    local barNumber = tonumber(parameterValue(barParameter))
    local beatNumber = tonumber(parameterValue(beatParameter))
    local state = runtime:get_state()

    if state.transitioning or
       not state.ready or
       barNumber == nil or
       beatNumber == nil or
       not isValid(context) or
       not isValid(currentWorld()) or
       not belongsToCurrentWorld(context) then
        return
    end

    if activeBeatSourceGeneration ~= state.generation then
        activeBeatSourceGeneration = state.generation
        activeBeatSource = nil
    end

    if activeBeatSource == nil then
        activeBeatSource = source
        report("LIFECYCLE", string.format(
            "music_beat_source generation=%d source=%s firstBar=%s firstBeat=%s",
            state.generation,
            source,
            tostring(barNumber),
            tostring(beatNumber)))
        if writeRuntimeHealth ~= nil then
            writeRuntimeHealth("music-beat-source")
        end
    elseif activeBeatSource ~= source then
        return
    end

    runtime:mark_music_beat(barNumber, beatNumber)
end

local function registerBeatHook(hook)
    return pcall(function()
        return RegisterHook(
            hook.path,
            function(contextParameter, barParameter, beatParameter)
                handleMusicBeat(
                    hook.source,
                    contextParameter,
                    barParameter,
                    beatParameter)
            end)
    end)
end

local registeredBeatHookCount = 0
for _, hook in ipairs(NATIVE_BEAT_HOOKS) do
    local registered, preId, postId = registerBeatHook(hook)

    if registered then
        registeredBeatHookCount = registeredBeatHookCount + 1
        report("HOOKS", string.format(
            "registered musicBeatSource=%s pre=%s post=%s",
            hook.source,
            tostring(preId),
            tostring(postId)))
    else
        report("WARN", string.format(
            "Music beat source unavailable source=%s detail=%s",
            hook.source,
            tostring(preId)))
    end
end

if registeredBeatHookCount == 0 then
    report("WARN", "No music beat hooks were available")
end

local preHookOk, preHookDetail = pcall(function()
    RegisterLoadMapPreHook(function()
        resetNotifications()
        resetMeters()
        local generation = runtime:begin_transition()
        report("LIFECYCLE", "transition_started generation=" .. tostring(generation))
    end)
end)
if not preHookOk then
    report("ERROR", "LoadMap pre-hook failed: " .. tostring(preHookDetail))
end

local postHookOk, postHookDetail = pcall(function()
    RegisterLoadMapPostHook(function()
        runtime:complete_transition(currentScene())
        report("LIFECYCLE", string.format(
            "transition_finished generation=%d scene=%s",
            runtime:get_state().generation,
            currentScene()))
        scheduleReadyProbe("map-load")
        scheduleArenaSongHookRegistration("map-load")
        schedulePerfectInputHookRegistration("map-load")
        if writeRuntimeHealth ~= nil then
            writeRuntimeHealth("map-load")
        end
    end)
end)
if not postHookOk then
    report("ERROR", "LoadMap post-hook failed: " .. tostring(postHookDetail))
end

local playerHookOk, playerHookPreId, playerHookPostId = pcall(function()
    return RegisterHook(
        "/Script/Engine.PlayerController:ClientRestart",
        function(controllerParameter, pawnParameter)
            local controller = parameterValue(controllerParameter)
            local pawn = parameterValue(pawnParameter)

            if isValid(controller) and
               isValid(pawn) and
               belongsToCurrentWorld(controller) and
               belongsToCurrentWorld(pawn) then
                local emitted = runtime:mark_player_spawned(
                    objectToken(pawn),
                    playerIndex(controller),
                    isLocalController(controller))

                if emitted then
                    report("LIFECYCLE", string.format(
                        "player_spawned generation=%d playerIndex=%d local=%s",
                        runtime:get_state().generation,
                        playerIndex(controller),
                        tostring(isLocalController(controller))))
                end
                scheduleReadyProbe("client-restart", { 50, 250 })
            end
        end)
end)

if playerHookOk then
    report("HOOKS", string.format(
        "registered mapPre=%s mapPost=%s clientRestartPre=%s clientRestartPost=%s",
        tostring(preHookOk),
        tostring(postHookOk),
        tostring(playerHookPreId),
        tostring(playerHookPostId)))
else
    report("ERROR", "ClientRestart hook failed: " .. tostring(playerHookPreId))
end

runtime:complete_transition(currentScene())
scheduleReadyProbe("startup", { 1000, 2500, 5000 })
scheduleArenaSongHookRegistration("startup")
schedulePerfectInputHookRegistration("startup")

writeRuntimeHealth = function(reason)
    local state = runtime:get_state()
    local wrote, detail = runtime:write_health_report({
        report_reason = tostring(reason),
        generation = state.generation,
        scene = state.scene,
        transitioning = state.transitioning,
        hooks = {
            transition = preHookOk and postHookOk,
            player_spawn = playerHookOk,
            song_native = songHooks.native,
            song_arena = songHooks.arena,
            music_beat_registered_sources = registeredBeatHookCount,
            music_beat_active_source = activeBeatSource or "none",
            combat_perfect_input = perfectInputHookRegistered,
            hud_meter = true,
            private_input_grade_probe =
                inputGradeProbeOk or
                inputGradeParamProbeOk or
                inputGradeReturnProbeOk or
                abilityInputGradeReturnProbeOk,
            private_input_grade_probe_sources =
                (inputGradeProbeOk and 1 or 0) +
                (inputGradeParamProbeOk and 1 or 0) +
                (inputGradeReturnProbeOk and 1 or 0) +
                (abilityInputGradeReturnProbeOk and 1 or 0),
            private_hit_word_cue_probe =
                registeredHitWordCueHookCount > 0,
            private_hit_word_cue_probe_sources =
                registeredHitWordCueHookCount,
            private_hit_word_asset_probe =
                hitWordAssetProbeOk
        },
        duplicate_hook_prevention = {
            single_registration_flags = true,
            generation_scoped_timing_source = true,
            transition_generation_guards = true,
            visual_cue_recursion_guard = true
        }
    })
    if not wrote then
        report("WARN", "Runtime health report unavailable: " .. tostring(detail))
    end
end

writeRuntimeHealth("startup")

report("INFO", string.format(
    "Version %s loaded behind Limelight. API=%s LuaSecureSandbox=false",
    Runtime.VERSION,
    Runtime.API_VERSION))

return runtime
