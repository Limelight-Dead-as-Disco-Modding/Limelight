local json = require("stagehand.json")

local Runtime = {}
Runtime.__index = Runtime

Runtime.VERSION = "0.5.1-prototype"
Runtime.API_VERSION = "1.3.0"

local eventPermissions = {
    ["transition.started"] = "events.transition_started",
    ["game.ready"] = "events.game_ready",
    ["arena.loaded"] = "events.arena_loaded",
    ["player.spawned"] = "events.player_spawned",
    ["song.changed"] = "events.song_changed",
    ["music.beat"] = "events.music_beat",
    ["combat.perfect_input"] = "events.combat_perfect_input"
}

local supportedPermissions = {
    ["events.transition_started"] = true,
    ["events.game_ready"] = true,
    ["events.arena_loaded"] = true,
    ["events.player_spawned"] = true,
    ["events.song_changed"] = true,
    ["events.music_beat"] = true,
    ["events.combat_perfect_input"] = true,
    ["actions.notify"] = true,
    ["actions.visual_cue"] = true,
    ["actions.meter"] = true,
    ["state.read"] = true,
    ["settings.read"] = true,
    ["settings.write"] = true,
    ["storage.read"] = true,
    ["storage.write"] = true,
    ["logging"] = true
}

local permissionCapabilities = {
    ["events.transition_started"] = "lifecycle.transitions",
    ["events.game_ready"] = "lifecycle.game-ready",
    ["events.arena_loaded"] = "lifecycle.arena",
    ["events.player_spawned"] = "lifecycle.player-spawn",
    ["events.song_changed"] = "music.song",
    ["events.music_beat"] = "music.beat",
    ["events.combat_perfect_input"] = "combat.perfect-input",
    ["actions.notify"] = "hud.notification",
    ["actions.visual_cue"] = "hud.visual-cue",
    ["actions.meter"] = "hud.meter",
    ["state.read"] = "state.stable-read",
    ["settings.read"] = "data.settings",
    ["settings.write"] = "data.settings",
    ["storage.read"] = "data.storage",
    ["storage.write"] = "data.storage",
    ["logging"] = "diagnostics.logging"
}

local supportedCapabilities = {
    ["lifecycle.transitions"] = true,
    ["lifecycle.game-ready"] = true,
    ["lifecycle.arena"] = true,
    ["lifecycle.player-spawn"] = true,
    ["music.song"] = true,
    ["music.beat"] = true,
    ["combat.perfect-input"] = true,
    ["hud.notification"] = true,
    ["hud.visual-cue"] = true,
    ["hud.meter"] = true,
    ["state.stable-read"] = true,
    ["data.settings"] = true,
    ["data.storage"] = true,
    ["diagnostics.logging"] = true
}

local function copyTable(source)
    local result = json.is_array(source) and json.array() or {}
    for key, value in pairs(source) do
        result[key] = value
    end
    return result
end

local function copyValue(value, seen)
    if type(value) ~= "table" then
        return value
    end

    if value == json.null then
        return json.null
    end

    seen = seen or {}
    if seen[value] then
        error("Stagehand values cannot contain circular tables", 0)
    end
    seen[value] = true

    local result = {}
    for key, child in pairs(value) do
        result[copyValue(key, seen)] = copyValue(child, seen)
    end

    seen[value] = nil
    return result
end

local function readOnly(value, label)
    return setmetatable({}, {
        __index = value,
        __newindex = function()
            error((label or "Stagehand API table") .. " is read-only", 2)
        end,
        __metatable = "locked"
    })
end

local function copiedLibrary(source)
    local copy = {}
    for key, value in pairs(source) do
        if type(value) == "function" or
           type(value) == "number" or
           type(value) == "string" or
           type(value) == "boolean" then
            copy[key] = value
        end
    end
    return readOnly(copy, "standard library")
end

local function parseApiVersion(value)
    if type(value) ~= "string" then
        return nil
    end

    local major, minor = value:match("^(%d+)%.(%d+)$")
    if major == nil then
        major, minor = value:match("^(%d+)%.(%d+)%.%d+$")
    end

    if major == nil then
        return nil
    end

    return tonumber(major), tonumber(minor)
end

local function isValidModId(value)
    return type(value) == "string" and
        #value <= 96 and
        value:match("^[a-z0-9][a-z0-9._-]*$") ~= nil
end

local function parseSemanticVersion(value)
    if type(value) ~= "string" then
        return nil
    end

    if value:match("^%d+%.%d+%.%d+[-+A-Za-z0-9.]*$") == nil then
        return nil
    end

    local major, minor, patch = value:match("^(%d+)%.(%d+)%.(%d+)")
    if major == nil then
        return nil
    end
    return tonumber(major), tonumber(minor), tonumber(patch)
end

local function versionAtLeast(actual, minimum)
    local actualMajor, actualMinor, actualPatch = parseSemanticVersion(actual)
    local minimumMajor, minimumMinor, minimumPatch =
        parseSemanticVersion(minimum)
    if actualMajor == nil or minimumMajor == nil then
        return false
    end

    if actualMajor ~= minimumMajor then
        return actualMajor > minimumMajor
    end
    if actualMinor ~= minimumMinor then
        return actualMinor > minimumMinor
    end
    return actualPatch >= minimumPatch
end

local function sortedKeys(source)
    local result = json.array()
    for key in pairs(source) do
        result[#result + 1] = key
    end
    table.sort(result)
    return result
end

local function validateKey(key)
    return type(key) == "string" and
        #key >= 1 and
        #key <= 64 and
        key:match("^[A-Za-z0-9_.-]+$") ~= nil
end

local function validateManifest(manifest)
    if type(manifest) ~= "table" or json.is_array(manifest) then
        return nil, "manifest root must be an object"
    end

    if manifest.schemaVersion ~= 1 then
        return nil, "schemaVersion must be 1"
    end

    if not isValidModId(manifest.id) then
        return nil, "id must be a lowercase namespaced identifier"
    end

    if type(manifest.name) ~= "string" or
       #manifest.name < 1 or
       #manifest.name > 96 then
        return nil, "name must contain between 1 and 96 characters"
    end

    if type(manifest.version) ~= "string" or
       manifest.version:match("^%d+%.%d+%.%d+[-+A-Za-z0-9.]*$") == nil then
        return nil, "version must be a semantic version"
    end

    local requestedMajor, requestedMinor = parseApiVersion(manifest.apiVersion)
    local availableMajor, availableMinor = parseApiVersion(Runtime.API_VERSION)
    if requestedMajor == nil or
       requestedMajor ~= availableMajor or
       requestedMinor > availableMinor then
        return nil, string.format(
            "apiVersion %s is not supported by Stagehand API %s",
            tostring(manifest.apiVersion),
            Runtime.API_VERSION)
    end

    if type(manifest.entrypoint) ~= "string" or
       #manifest.entrypoint > 80 or
       manifest.entrypoint:match("^[A-Za-z0-9_.-]+%.lua$") == nil then
        return nil, "entrypoint must be a direct .lua filename"
    end

    if manifest.nativeCode ~= false then
        return nil, "nativeCode must be false; Stagehand v0 only loads Lua"
    end

    if type(manifest.declaredTrust) ~= "string" or
       #manifest.declaredTrust < 1 or
       #manifest.declaredTrust > 80 then
        return nil, "declaredTrust is required for trust reporting"
    end

    if type(manifest.permissions) ~= "table" or
       not json.is_array(manifest.permissions) then
        return nil, "permissions must be an array"
    end

    local permissionSet = {}
    local permissionList = {}
    for index, permission in ipairs(manifest.permissions) do
        if type(permission) ~= "string" or not supportedPermissions[permission] then
            return nil, "unsupported permission at index " .. tostring(index)
        end
        if permissionSet[permission] then
            return nil, "duplicate permission '" .. permission .. "'"
        end
        permissionSet[permission] = true
        permissionList[#permissionList + 1] = permission
    end
    table.sort(permissionList)

    local capabilitySet = {}
    local capabilityList = json.array()
    local capabilityDeclaration = "explicit"
    if manifest.capabilities == nil then
        capabilityDeclaration = "legacy-inferred"
        for _, permission in ipairs(permissionList) do
            local capability = permissionCapabilities[permission]
            if capability ~= nil and not capabilitySet[capability] then
                capabilitySet[capability] = true
                capabilityList[#capabilityList + 1] = capability
            end
        end
    elseif type(manifest.capabilities) ~= "table" or
           not json.is_array(manifest.capabilities) then
        return nil, "capabilities must be an array"
    else
        for index, capability in ipairs(manifest.capabilities) do
            if type(capability) ~= "string" or
               not supportedCapabilities[capability] then
                return nil, "unsupported capability at index " .. tostring(index)
            end
            if capabilitySet[capability] then
                return nil, "duplicate capability '" .. capability .. "'"
            end
            capabilitySet[capability] = true
            capabilityList[#capabilityList + 1] = capability
        end
    end
    table.sort(capabilityList)

    if capabilityDeclaration == "explicit" then
        for _, permission in ipairs(permissionList) do
            local capability = permissionCapabilities[permission]
            if capability ~= nil and not capabilitySet[capability] then
                return nil, string.format(
                    "permission '%s' requires capability '%s'",
                    permission,
                    capability)
            end
        end
    end

    local dependencies = json.array()
    local dependencySet = {}
    if manifest.dependencies ~= nil and
       (type(manifest.dependencies) ~= "table" or
        not json.is_array(manifest.dependencies)) then
        return nil, "dependencies must be an array"
    end

    for index, dependency in ipairs(manifest.dependencies or {}) do
        if type(dependency) ~= "table" or json.is_array(dependency) then
            return nil, "dependency at index " .. tostring(index) ..
                " must be an object"
        end

        local dependencyId = dependency.id
        local minimumVersion = dependency.minimumVersion or "0.0.0"
        local optional = dependency.optional == true
        if not isValidModId(dependencyId) or dependencyId == manifest.id then
            return nil, "dependency at index " .. tostring(index) ..
                " has an invalid or self-referencing id"
        end
        if parseSemanticVersion(minimumVersion) == nil then
            return nil, "dependency at index " .. tostring(index) ..
                " has an invalid minimumVersion"
        end
        if dependency.optional ~= nil and type(dependency.optional) ~= "boolean" then
            return nil, "dependency at index " .. tostring(index) ..
                " has a non-boolean optional flag"
        end
        if dependencySet[dependencyId] then
            return nil, "duplicate dependency '" .. dependencyId .. "'"
        end
        dependencySet[dependencyId] = true
        dependencies[#dependencies + 1] = {
            id = dependencyId,
            minimum_version = minimumVersion,
            optional = optional
        }
    end
    table.sort(dependencies, function(left, right)
        return left.id < right.id
    end)

    return {
        id = manifest.id,
        name = manifest.name,
        version = manifest.version,
        apiVersion = manifest.apiVersion,
        entrypoint = manifest.entrypoint,
        declaredTrust = manifest.declaredTrust,
        nativeCode = false,
        permissions = permissionList,
        permissionSet = permissionSet,
        capabilities = capabilityList,
        capabilitySet = capabilitySet,
        capabilityDeclaration = capabilityDeclaration,
        dependencies = dependencies
    }
end

function Runtime.new(host)
    if type(host) ~= "table" then
        error("Stagehand requires a host adapter", 2)
    end

    local requiredHostFunctions = {
        "print",
        "now",
        "read_file",
        "write_file_atomic",
        "append_file",
        "load_file",
        "list_logic_mod_directories",
        "data_file",
        "notify",
        "visual_cue",
        "meter",
        "clear_meter"
    }

    for _, functionName in ipairs(requiredHostFunctions) do
        if type(host[functionName]) ~= "function" then
            error("Stagehand host is missing '" .. functionName .. "'", 2)
        end
    end

    local self = setmetatable({}, Runtime)
    self.host = host
    self.listeners = {}
    self.loadedMods = {}
    self.loadedModOrder = {}
    self.state = {
        generation = 0,
        transitioning = false,
        ready = false,
        playerReady = false,
        scene = "unknown"
    }
    self.readyGeneration = nil
    self.spawnedTokens = {}
    self.lastSongToken = nil
    self.lastBeatKey = nil
    self.beatSequence = 0
    self.perfectInputSequence = 0
    self.discovery = {
        loaded = json.array(),
        rejected = json.array()
    }
    return self
end

function Runtime:_print(level, message)
    self.host.print(string.format(
        "[LimelightStagehand][%s] %s",
        level,
        tostring(message)))
end

function Runtime:_writeModLog(mod, level, message)
    local cleanMessage = tostring(message)
        :gsub("\r\n", "\n")
        :gsub("\r", "\n")
        :gsub("%z", "")

    local line = string.format(
        "%s [%s] [%s] %s\n",
        self.host.now(),
        level,
        mod.id,
        cleanMessage:gsub("\n", "\\n"))

    local path = self.host.data_file(mod, "stagehand.log")
    local ok, detail = self.host.append_file(path, line)
    if not ok then
        self:_print("WARN", string.format(
            "Could not write log for %s: %s",
            mod.id,
            tostring(detail)))
    end
end

function Runtime:_requirePermission(mod, permission)
    if not mod.permissionSet[permission] then
        error(string.format(
            "Stagehand permission '%s' was not declared by %s",
            permission,
            mod.id), 3)
    end
end

function Runtime:_readNamespace(mod, fileName)
    local path = self.host.data_file(mod, fileName)
    local contents, detail = self.host.read_file(path)
    if contents == nil then
        if detail == "not-found" then
            return {}
        end
        error("Could not read " .. fileName .. ": " .. tostring(detail), 3)
    end

    local ok, value = pcall(json.decode, contents)
    if not ok or type(value) ~= "table" or json.is_array(value) then
        error("Could not parse " .. fileName .. ": " .. tostring(value), 3)
    end
    return value
end

function Runtime:_writeNamespace(mod, fileName, value)
    local ok, encoded = pcall(json.encode, value)
    if not ok then
        error("Could not encode " .. fileName .. ": " .. tostring(encoded), 3)
    end

    local path = self.host.data_file(mod, fileName)
    local written, detail = self.host.write_file_atomic(path, encoded .. "\n")
    if not written then
        error("Could not write " .. fileName .. ": " .. tostring(detail), 3)
    end
end

function Runtime:_subscribe(mod, eventName, callback)
    local permission = eventPermissions[eventName]
    if permission == nil then
        error("Unknown Stagehand event '" .. tostring(eventName) .. "'", 3)
    end
    self:_requirePermission(mod, permission)

    if type(callback) ~= "function" then
        error("Stagehand event callback must be a function", 3)
    end

    local listeners = self.listeners[eventName]
    if listeners == nil then
        listeners = {}
        self.listeners[eventName] = listeners
    end

    listeners[#listeners + 1] = {
        mod = mod,
        callback = callback
    }

    return #listeners
end

function Runtime:_makeApi(mod)
    local settingsCache = nil
    local storageCache = nil

    local events = {
        on = function(eventName, callback)
            return self:_subscribe(mod, eventName, callback)
        end
    }

    local state = {
        get = function()
            self:_requirePermission(mod, "state.read")
            return copyValue(self.state)
        end
    }

    local settings = {
        get = function(key, defaultValue)
            self:_requirePermission(mod, "settings.read")
            if not validateKey(key) then
                error("Stagehand setting keys may only use letters, numbers, '.', '_' and '-'", 2)
            end
            settingsCache = settingsCache or self:_readNamespace(mod, "settings.json")
            local value = settingsCache[key]
            if value == nil then
                return copyValue(defaultValue)
            end
            return copyValue(value)
        end,
        set = function(key, value)
            self:_requirePermission(mod, "settings.write")
            if not validateKey(key) then
                error("Stagehand setting keys may only use letters, numbers, '.', '_' and '-'", 2)
            end
            settingsCache = settingsCache or self:_readNamespace(mod, "settings.json")
            settingsCache[key] = copyValue(value)
            self:_writeNamespace(mod, "settings.json", settingsCache)
            return true
        end
    }

    local storage = {
        get = function(key, defaultValue)
            self:_requirePermission(mod, "storage.read")
            if not validateKey(key) then
                error("Stagehand storage keys may only use letters, numbers, '.', '_' and '-'", 2)
            end
            storageCache = storageCache or self:_readNamespace(mod, "storage.json")
            local value = storageCache[key]
            if value == nil then
                return copyValue(defaultValue)
            end
            return copyValue(value)
        end,
        set = function(key, value)
            self:_requirePermission(mod, "storage.write")
            if not validateKey(key) then
                error("Stagehand storage keys may only use letters, numbers, '.', '_' and '-'", 2)
            end
            storageCache = storageCache or self:_readNamespace(mod, "storage.json")
            storageCache[key] = copyValue(value)
            self:_writeNamespace(mod, "storage.json", storageCache)
            return true
        end
    }

    local logging = {}
    for _, level in ipairs({ "debug", "info", "warn", "error" }) do
        local capturedLevel = level:upper()
        logging[level] = function(message)
            self:_requirePermission(mod, "logging")
            self:_writeModLog(mod, capturedLevel, message)
        end
    end

    local actions = {
        notify = function(message, durationSeconds)
            self:_requirePermission(mod, "actions.notify")
            if type(message) ~= "string" or #message < 1 or #message > 180 then
                error("Stagehand notifications must contain between 1 and 180 characters", 2)
            end

            local duration = tonumber(durationSeconds) or 5.0
            duration = math.max(1.0, math.min(10.0, duration))
            return self.host.notify(
                mod.id,
                mod.name,
                message,
                duration,
                copyValue(self.state))
        end,
        visual_cue = function(cueName)
            self:_requirePermission(mod, "actions.visual_cue")
            if cueName ~= "beat-accent" then
                error("Stagehand visual cue must currently be 'beat-accent'", 2)
            end

            return self.host.visual_cue(
                mod.id,
                cueName,
                copyValue(self.state))
        end,
        meter = function(meterId, value, maximum, label)
            self:_requirePermission(mod, "actions.meter")
            if type(meterId) ~= "string" or
               meterId:match("^[a-z][a-z0-9_.-]*$") == nil or
               #meterId > 32 then
                error("Stagehand meter IDs must be lowercase identifiers up to 32 characters", 2)
            end

            local numericValue = tonumber(value)
            local numericMaximum = tonumber(maximum)
            if numericValue == nil or
               numericMaximum == nil or
               numericValue ~= numericValue or
               numericMaximum ~= numericMaximum or
               numericMaximum <= 0 or
               numericMaximum > 1000000 then
                error("Stagehand meters require finite values and a positive maximum", 2)
            end

            local meterLabel = label
            if meterLabel == nil then
                meterLabel = meterId:gsub("[._-]+", " "):upper()
            end
            if type(meterLabel) ~= "string" then
                error("Stagehand meter labels must be text", 2)
            end
            meterLabel = meterLabel:gsub("^%s+", ""):gsub("%s+$", "")
            if #meterLabel < 1 or #meterLabel > 24 or meterLabel:match("%c") then
                error("Stagehand meter labels must contain between 1 and 24 printable characters", 2)
            end

            return self.host.meter(
                mod.id,
                meterId,
                numericValue,
                numericMaximum,
                meterLabel,
                copyValue(self.state))
        end,
        clear_meter = function(meterId)
            self:_requirePermission(mod, "actions.meter")
            if type(meterId) ~= "string" or
               meterId:match("^[a-z][a-z0-9_.-]*$") == nil or
               #meterId > 32 then
                error("Stagehand meter IDs must be lowercase identifiers up to 32 characters", 2)
            end

            return self.host.clear_meter(
                mod.id,
                meterId,
                copyValue(self.state))
        end
    }

    return readOnly({
        api_version = Runtime.API_VERSION,
        runtime_version = Runtime.VERSION,
        mod = readOnly({
            id = mod.id,
            name = mod.name,
            version = mod.version,
            declared_trust = mod.declaredTrust,
            native_code = false
        }, "Stagehand mod metadata"),
        events = readOnly(events, "Stagehand events API"),
        state = readOnly(state, "Stagehand state API"),
        settings = readOnly(settings, "Stagehand settings API"),
        storage = readOnly(storage, "Stagehand storage API"),
        log = readOnly(logging, "Stagehand logging API"),
        actions = readOnly(actions, "Stagehand actions API")
    }, "Stagehand API")
end

function Runtime:_makeEnvironment(mod)
    local environment = {
        _VERSION = _VERSION,
        assert = assert,
        error = error,
        ipairs = ipairs,
        next = next,
        pairs = pairs,
        pcall = pcall,
        select = select,
        tonumber = tonumber,
        tostring = tostring,
        type = type,
        xpcall = xpcall,
        math = copiedLibrary(math),
        string = copiedLibrary(string),
        table = copiedLibrary(table),
        utf8 = copiedLibrary(utf8),
        stagehand = self:_makeApi(mod)
    }

    return environment
end

function Runtime:_removeListenersForMod(mod)
    for eventName, listeners in pairs(self.listeners) do
        local kept = {}
        for _, listener in ipairs(listeners) do
            if listener.mod ~= mod then
                kept[#kept + 1] = listener
            end
        end
        self.listeners[eventName] = kept
    end
end

function Runtime:_findFile(directory, fileName)
    for _, file in ipairs(directory.files or {}) do
        if file.name == fileName then
            return file.path
        end
    end
    return nil
end

function Runtime:_recordRejected(directoryName, modId, reason)
    local rejection = {
        directory = tostring(directoryName),
        reason = tostring(reason)
    }
    if modId ~= nil then
        rejection.id = tostring(modId)
    end
    self.discovery.rejected[#self.discovery.rejected + 1] = rejection
end

function Runtime:_inspectDirectory(directory)
    local manifestPath = self:_findFile(directory, "stagehand.json")
    if manifestPath == nil then
        return false, "no-manifest"
    end

    local manifestText, readDetail = self.host.read_file(manifestPath)
    if manifestText == nil then
        return false, "could not read manifest: " .. tostring(readDetail)
    end

    local decodedOk, decoded = pcall(json.decode, manifestText)
    if not decodedOk then
        return false, "invalid manifest JSON: " .. tostring(decoded)
    end

    local mod, validationDetail = validateManifest(decoded)
    if mod == nil then
        return false, "invalid manifest: " .. validationDetail
    end

    local entryPath = self:_findFile(directory, mod.entrypoint)
    if entryPath == nil then
        return false, "entrypoint '" .. mod.entrypoint .. "' was not found"
    end

    mod.directory = directory.path
    return true, {
        directoryName = tostring(directory.name),
        entryPath = entryPath,
        mod = mod,
        status = "pending"
    }
end

function Runtime:_loadCandidate(candidate)
    local mod = candidate.mod
    if self.loadedMods[mod.id] ~= nil then
        return false, "duplicate mod id '" .. mod.id .. "'"
    end

    local dependencySummary = {}
    for _, dependency in ipairs(mod.dependencies) do
        dependencySummary[#dependencySummary + 1] = string.format(
            "%s>=%s%s",
            dependency.id,
            dependency.minimum_version,
            dependency.optional and "?" or "")
    end

    self:_print("TRUST", string.format(
        "mod=%s declared_trust=%s self_reported=true native_code=false permissions=%s capabilities=%s capability_declaration=%s dependencies=%s lua_secure_sandbox=false",
        mod.id,
        mod.declaredTrust,
        table.concat(mod.permissions, ","),
        table.concat(mod.capabilities, ","),
        mod.capabilityDeclaration,
        table.concat(dependencySummary, ",")))

    local environment = self:_makeEnvironment(mod)
    local chunk, loadDetail = self.host.load_file(candidate.entryPath, environment)
    if chunk == nil then
        return false, "could not load entrypoint: " .. tostring(loadDetail)
    end

    local executed, result = pcall(chunk)
    if not executed then
        self:_removeListenersForMod(mod)
        self:_writeModLog(mod, "ERROR", "Entrypoint failed: " .. tostring(result))
        return false, "entrypoint failed: " .. tostring(result)
    end

    mod.module = result
    self.loadedMods[mod.id] = mod
    self.loadedModOrder[#self.loadedModOrder + 1] = mod
    self.discovery.loaded[#self.discovery.loaded + 1] = mod.id
    self:_writeModLog(mod, "INFO", string.format(
        "Loaded with Stagehand API %s; Lua execution is trusted code, not a secure sandbox.",
        Runtime.API_VERSION))
    return true, mod
end

function Runtime:load_all()
    local directories = self.host.list_logic_mod_directories()
    if type(directories) ~= "table" then
        error("Stagehand host did not return a logic-mod directory list", 2)
    end

    table.sort(directories, function(left, right)
        return tostring(left.name):lower() < tostring(right.name):lower()
    end)

    self.discovery = {
        loaded = json.array(),
        rejected = json.array()
    }

    local groups = {}
    for _, directory in ipairs(directories) do
        local ok, detail = self:_inspectDirectory(directory)
        if ok then
            groups[detail.mod.id] = groups[detail.mod.id] or json.array()
            groups[detail.mod.id][#groups[detail.mod.id] + 1] = detail
        elseif detail ~= "no-manifest" then
            self:_recordRejected(directory.name, nil, detail)
            self:_print("ERROR", string.format(
                "Rejected logic-mod directory %s: %s",
                tostring(directory.name),
                tostring(detail)))
        end
    end

    local candidates = json.array()
    local candidatesById = {}
    for id, group in pairs(groups) do
        if #group == 1 then
            candidates[#candidates + 1] = group[1]
            candidatesById[id] = group[1]
        else
            for _, candidate in ipairs(group) do
                candidate.status = "rejected"
                local reason = "duplicate mod id '" .. id .. "'"
                self:_recordRejected(candidate.directoryName, id, reason)
                self:_print("ERROR", string.format(
                    "Rejected logic-mod directory %s: %s",
                    candidate.directoryName,
                    reason))
            end
        end
    end

    table.sort(candidates, function(left, right)
        return left.directoryName:lower() < right.directoryName:lower()
    end)

    local function rejectCandidate(candidate, reason)
        if candidate.status ~= "pending" then
            return
        end
        candidate.status = "rejected"
        self:_recordRejected(
            candidate.directoryName,
            candidate.mod.id,
            reason)
        self:_print("ERROR", string.format(
            "Rejected logic-mod directory %s: %s",
            candidate.directoryName,
            reason))
    end

    for _, candidate in ipairs(candidates) do
        for _, dependency in ipairs(candidate.mod.dependencies) do
            if not dependency.optional then
                local provider = candidatesById[dependency.id]
                local providerMod = provider and provider.mod or
                    self.loadedMods[dependency.id]
                if providerMod == nil then
                    rejectCandidate(candidate, string.format(
                        "missing required dependency '%s' >= %s",
                        dependency.id,
                        dependency.minimum_version))
                    break
                end
                if not versionAtLeast(
                        providerMod.version,
                        dependency.minimum_version) then
                    rejectCandidate(candidate, string.format(
                        "dependency '%s' is %s but >= %s is required",
                        dependency.id,
                        tostring(providerMod.version),
                        dependency.minimum_version))
                    break
                end
            end
        end
    end

    local remaining = true
    while remaining do
        remaining = false
        local progressed = false

        for _, candidate in ipairs(candidates) do
            if candidate.status == "pending" then
                remaining = true
                local waiting = false
                local blockedBy = nil

                for _, dependency in ipairs(candidate.mod.dependencies) do
                    if not dependency.optional then
                        local provider = candidatesById[dependency.id]
                        if provider ~= nil and provider.status == "pending" then
                            waiting = true
                        elseif provider ~= nil and provider.status == "rejected" then
                            blockedBy = dependency.id
                            break
                        end
                    end
                end

                if blockedBy ~= nil then
                    rejectCandidate(candidate,
                        "required dependency '" .. blockedBy .. "' was rejected")
                    progressed = true
                elseif not waiting then
                    local loadedOk, loadedDetail = self:_loadCandidate(candidate)
                    if loadedOk then
                        candidate.status = "loaded"
                        self:_print("INFO", string.format(
                            "Loaded logic mod %s (%s)",
                            loadedDetail.id,
                            loadedDetail.version))
                    else
                        rejectCandidate(candidate, loadedDetail)
                    end
                    progressed = true
                end
            end
        end

        if remaining and not progressed then
            for _, candidate in ipairs(candidates) do
                if candidate.status == "pending" then
                    rejectCandidate(candidate,
                        "dependency cycle or unresolved load order")
                end
            end
            remaining = false
        end
    end

    local loaded = #self.discovery.loaded
    local rejected = #self.discovery.rejected

    self:_print("INFO", string.format(
        "Discovery complete: loaded=%d rejected=%d API=%s",
        loaded,
        rejected,
        Runtime.API_VERSION))
    return loaded, rejected
end

function Runtime:get_health_report(adapterHealth)
    local loadedMods = json.array()
    for _, mod in ipairs(self.loadedModOrder) do
        local permissions = json.array()
        for _, permission in ipairs(mod.permissions) do
            permissions[#permissions + 1] = permission
        end

        local capabilities = json.array()
        for _, capability in ipairs(mod.capabilities) do
            capabilities[#capabilities + 1] = capability
        end

        local dependencies = json.array()
        for _, dependency in ipairs(mod.dependencies) do
            dependencies[#dependencies + 1] = copyValue(dependency)
        end

        loadedMods[#loadedMods + 1] = {
            id = mod.id,
            name = mod.name,
            version = mod.version,
            api_version = mod.apiVersion,
            declared_trust = mod.declaredTrust,
            native_code = false,
            permissions = permissions,
            capabilities = capabilities,
            capability_declaration = mod.capabilityDeclaration,
            dependencies = dependencies
        }
    end

    local rejectedMods = json.array()
    for _, rejection in ipairs(self.discovery.rejected) do
        rejectedMods[#rejectedMods + 1] = copyValue(rejection)
    end

    return {
        schema_version = 1,
        status = #rejectedMods == 0 and "healthy" or "degraded",
        runtime_version = Runtime.VERSION,
        api_version = Runtime.API_VERSION,
        lua_secure_sandbox = false,
        supported_capabilities = sortedKeys(supportedCapabilities),
        discovery = {
            loaded_count = #loadedMods,
            rejected_count = #rejectedMods,
            loaded_mods = loadedMods,
            rejected_mods = rejectedMods
        },
        ownership = {
            stagehand_files_only = true,
            bundles_native_dlls = false,
            replaces_ue4ss_runtime = false,
            replaces_signatures = false,
            replaces_third_party_mods = false
        },
        adapters = copyValue(adapterHealth or {})
    }
end

function Runtime:write_health_report(adapterHealth)
    if type(self.host.write_health_report) ~= "function" then
        return false, "health-report-host-unavailable"
    end

    local encodedOk, contents = pcall(function()
        return json.encode(self:get_health_report(adapterHealth)) .. "\n"
    end)
    if not encodedOk then
        self:_print("WARN", "Could not encode health report: " .. tostring(contents))
        return false, contents
    end

    local wrote, detail = self.host.write_health_report(contents)
    if not wrote then
        self:_print("WARN", "Could not write health report: " .. tostring(detail))
        return false, detail
    end
    return true, "written"
end

function Runtime:emit(eventName, payload)
    local listeners = self.listeners[eventName]
    if listeners == nil or #listeners == 0 then
        return 0
    end

    local snapshot = {}
    for index, listener in ipairs(listeners) do
        snapshot[index] = listener
    end

    local delivered = 0
    for _, listener in ipairs(snapshot) do
        local callbackPayload = copyValue(payload or {})
        local ok, detail = pcall(listener.callback, callbackPayload)
        if ok then
            delivered = delivered + 1
        else
            self:_writeModLog(listener.mod, "ERROR", string.format(
                "Event %s failed: %s",
                eventName,
                tostring(detail)))
        end
    end

    return delivered
end

function Runtime:begin_transition()
    self.state.generation = self.state.generation + 1
    self.state.transitioning = true
    self.state.ready = false
    self.state.playerReady = false
    self.state.scene = "unknown"
    self.state.songKey = nil
    self.readyGeneration = nil
    self.spawnedTokens = {}
    self.lastSongToken = nil
    self.lastBeatKey = nil
    self.beatSequence = 0
    self.perfectInputSequence = 0

    self:emit("transition.started", {
        generation = self.state.generation
    })
    return self.state.generation
end

function Runtime:complete_transition(scene)
    self.state.transitioning = false
    self.state.scene = scene or "unknown"
end

function Runtime:mark_player_spawned(token, playerIndex, isLocal)
    if self.state.transitioning or token == nil then
        return false
    end

    local tokenKey = tostring(token)
    if self.spawnedTokens[tokenKey] then
        return false
    end
    self.spawnedTokens[tokenKey] = true
    self.state.playerReady = true

    self:emit("player.spawned", {
        generation = self.state.generation,
        player_index = tonumber(playerIndex) or -1,
        is_local = isLocal == true
    })
    return true
end

function Runtime:mark_game_ready(scene)
    if self.state.transitioning or
       self.readyGeneration == self.state.generation then
        return false
    end

    self.readyGeneration = self.state.generation
    self.state.ready = true
    self.state.scene = scene or self.state.scene or "unknown"

    local payload = {
        generation = self.state.generation,
        scene = self.state.scene,
        player_ready = self.state.playerReady
    }
    self:emit("game.ready", payload)

    if self.state.scene == "arena" then
        self:emit("arena.loaded", {
            generation = self.state.generation,
            scene = "arena"
        })
    end
    return true
end

function Runtime:mark_song_changed(token, songKey)
    if self.state.transitioning or
       not self.state.ready or
       token == nil or
       type(songKey) ~= "string" or
       #songKey == 0 then
        return false
    end

    local tokenKey = tostring(token)
    if self.lastSongToken == tokenKey then
        return false
    end
    self.lastSongToken = tokenKey
    self.lastBeatKey = nil
    self.beatSequence = 0
    self.perfectInputSequence = 0
    self.state.songKey = songKey

    self:emit("song.changed", {
        generation = self.state.generation,
        scene = self.state.scene,
        song_key = songKey
    })
    return true
end

function Runtime:mark_music_beat(barNumber, beatNumber)
    local bar = tonumber(barNumber)
    local beat = tonumber(beatNumber)
    if self.state.transitioning or
       not self.state.ready or
       bar == nil or
       beat == nil then
        return false
    end

    bar = math.floor(bar)
    beat = math.floor(beat)
    if bar < 0 or beat < 0 then
        return false
    end

    local beatKey = tostring(bar) .. ":" .. tostring(beat)
    if self.lastBeatKey == beatKey then
        return false
    end

    self.lastBeatKey = beatKey
    self.beatSequence = self.beatSequence + 1
    self:emit("music.beat", {
        generation = self.state.generation,
        scene = self.state.scene,
        song_key = self.state.songKey or "unknown",
        bar = bar,
        beat = beat,
        sequence = self.beatSequence
    })
    return true
end

function Runtime:mark_combat_perfect_input(playerIndex)
    if self.state.transitioning or
       not self.state.ready or
       self.state.scene ~= "arena" then
        return false
    end

    self.perfectInputSequence = self.perfectInputSequence + 1
    self:emit("combat.perfect_input", {
        generation = self.state.generation,
        scene = self.state.scene,
        song_key = self.state.songKey or "unknown",
        player_index = tonumber(playerIndex) or -1,
        sequence = self.perfectInputSequence
    })
    return true
end

function Runtime:get_state()
    return copyValue(self.state)
end

function Runtime:listener_count(eventName)
    return #(self.listeners[eventName] or {})
end

function Runtime:loaded_mod_count()
    return #self.loadedModOrder
end

return Runtime
