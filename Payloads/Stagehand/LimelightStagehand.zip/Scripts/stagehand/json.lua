local json = {}

json.null = setmetatable({}, {
    __tostring = function()
        return "null"
    end
})

local arrayMarker = {}

local function decodeError(source, position, message)
    local line = 1
    local column = 1

    for index = 1, position - 1 do
        if source:sub(index, index) == "\n" then
            line = line + 1
            column = 1
        else
            column = column + 1
        end
    end

    error(string.format(
        "JSON error at line %d, column %d: %s",
        line,
        column,
        message), 0)
end

local function isWhitespace(character)
    return character == " " or
        character == "\t" or
        character == "\r" or
        character == "\n"
end

local function decode(source)
    if type(source) ~= "string" then
        error("JSON input must be a string", 2)
    end

    if source:sub(1, 3) == "\239\187\191" then
        source = source:sub(4)
    end

    local position = 1
    local length = #source
    local parseValue

    local function skipWhitespace()
        while position <= length and isWhitespace(source:sub(position, position)) do
            position = position + 1
        end
    end

    local function parseHexEscape()
        local digits = source:sub(position, position + 3)
        if #digits ~= 4 or not digits:match("^[0-9a-fA-F]+$") then
            decodeError(source, position, "invalid Unicode escape")
        end

        position = position + 4
        return tonumber(digits, 16)
    end

    local function parseString()
        position = position + 1
        local result = {}

        while position <= length do
            local character = source:sub(position, position)
            position = position + 1

            if character == "\"" then
                return table.concat(result)
            end

            if character == "\\" then
                if position > length then
                    decodeError(source, position, "unfinished escape sequence")
                end

                local escape = source:sub(position, position)
                position = position + 1

                local simpleEscapes = {
                    ['"'] = '"',
                    ["\\"] = "\\",
                    ["/"] = "/",
                    ["b"] = "\b",
                    ["f"] = "\f",
                    ["n"] = "\n",
                    ["r"] = "\r",
                    ["t"] = "\t"
                }

                if simpleEscapes[escape] ~= nil then
                    result[#result + 1] = simpleEscapes[escape]
                elseif escape == "u" then
                    local codePoint = parseHexEscape()

                    if codePoint >= 0xD800 and codePoint <= 0xDBFF then
                        if source:sub(position, position + 1) ~= "\\u" then
                            decodeError(source, position, "missing low surrogate")
                        end

                        position = position + 2
                        local lowSurrogate = parseHexEscape()
                        if lowSurrogate < 0xDC00 or lowSurrogate > 0xDFFF then
                            decodeError(source, position - 4, "invalid low surrogate")
                        end

                        codePoint = 0x10000 +
                            (codePoint - 0xD800) * 0x400 +
                            (lowSurrogate - 0xDC00)
                    elseif codePoint >= 0xDC00 and codePoint <= 0xDFFF then
                        decodeError(source, position - 4, "unexpected low surrogate")
                    end

                    result[#result + 1] = utf8.char(codePoint)
                else
                    decodeError(source, position - 1, "invalid escape sequence")
                end
            else
                if character:byte() < 0x20 then
                    decodeError(source, position - 1, "unescaped control character")
                end

                result[#result + 1] = character
            end
        end

        decodeError(source, position, "unterminated string")
    end

    local function parseNumber()
        local startPosition = position

        if source:sub(position, position) == "-" then
            position = position + 1
        end

        local firstDigit = source:sub(position, position)
        if firstDigit == "0" then
            position = position + 1
            if source:sub(position, position):match("%d") then
                decodeError(source, position, "leading zero in number")
            end
        elseif firstDigit:match("[1-9]") then
            repeat
                position = position + 1
            until not source:sub(position, position):match("%d")
        else
            decodeError(source, position, "invalid number")
        end

        if source:sub(position, position) == "." then
            position = position + 1
            if not source:sub(position, position):match("%d") then
                decodeError(source, position, "fraction requires a digit")
            end

            repeat
                position = position + 1
            until not source:sub(position, position):match("%d")
        end

        local exponent = source:sub(position, position)
        if exponent == "e" or exponent == "E" then
            position = position + 1
            local sign = source:sub(position, position)
            if sign == "+" or sign == "-" then
                position = position + 1
            end

            if not source:sub(position, position):match("%d") then
                decodeError(source, position, "exponent requires a digit")
            end

            repeat
                position = position + 1
            until not source:sub(position, position):match("%d")
        end

        local value = tonumber(source:sub(startPosition, position - 1))
        if value == nil then
            decodeError(source, startPosition, "invalid number")
        end

        return value
    end

    local function parseArray()
        position = position + 1
        skipWhitespace()

        local result = setmetatable({}, arrayMarker)
        if source:sub(position, position) == "]" then
            position = position + 1
            return result
        end

        while true do
            result[#result + 1] = parseValue()
            skipWhitespace()

            local delimiter = source:sub(position, position)
            if delimiter == "]" then
                position = position + 1
                return result
            end

            if delimiter ~= "," then
                decodeError(source, position, "expected ',' or ']' in array")
            end

            position = position + 1
            skipWhitespace()
        end
    end

    local function parseObject()
        position = position + 1
        skipWhitespace()

        local result = {}
        if source:sub(position, position) == "}" then
            position = position + 1
            return result
        end

        while true do
            if source:sub(position, position) ~= '"' then
                decodeError(source, position, "object key must be a string")
            end

            local key = parseString()
            if result[key] ~= nil then
                decodeError(source, position, "duplicate object key '" .. key .. "'")
            end

            skipWhitespace()
            if source:sub(position, position) ~= ":" then
                decodeError(source, position, "expected ':' after object key")
            end

            position = position + 1
            result[key] = parseValue()
            skipWhitespace()

            local delimiter = source:sub(position, position)
            if delimiter == "}" then
                position = position + 1
                return result
            end

            if delimiter ~= "," then
                decodeError(source, position, "expected ',' or '}' in object")
            end

            position = position + 1
            skipWhitespace()
        end
    end

    parseValue = function()
        skipWhitespace()

        local character = source:sub(position, position)
        if character == '"' then
            return parseString()
        elseif character == "{" then
            return parseObject()
        elseif character == "[" then
            return parseArray()
        elseif character == "-" or character:match("%d") then
            return parseNumber()
        elseif source:sub(position, position + 3) == "true" then
            position = position + 4
            return true
        elseif source:sub(position, position + 4) == "false" then
            position = position + 5
            return false
        elseif source:sub(position, position + 3) == "null" then
            position = position + 4
            return json.null
        end

        decodeError(source, position, "unexpected token")
    end

    local result = parseValue()
    skipWhitespace()
    if position <= length then
        decodeError(source, position, "trailing content")
    end

    return result
end

local escapeCharacters = {
    ['"'] = '\\"',
    ["\\"] = "\\\\",
    ["\b"] = "\\b",
    ["\f"] = "\\f",
    ["\n"] = "\\n",
    ["\r"] = "\\r",
    ["\t"] = "\\t"
}

local function encodeString(value)
    return '"' .. value:gsub('[%z\1-\31\\"]', function(character)
        return escapeCharacters[character] or
            string.format("\\u%04x", character:byte())
    end) .. '"'
end

local function isArray(value)
    if getmetatable(value) == arrayMarker then
        return true
    end

    local count = 0
    local maximum = 0
    for key in pairs(value) do
        if type(key) ~= "number" or key < 1 or key % 1 ~= 0 then
            return false
        end

        count = count + 1
        maximum = math.max(maximum, key)
    end

    return count > 0 and maximum == count
end

local function encode(value)
    local activeTables = {}

    local function encodeValue(current)
        local valueType = type(current)

        if current == json.null or valueType == "nil" then
            return "null"
        elseif valueType == "boolean" then
            return current and "true" or "false"
        elseif valueType == "number" then
            if current ~= current or current == math.huge or current == -math.huge then
                error("cannot encode a non-finite JSON number", 0)
            end
            return tostring(current)
        elseif valueType == "string" then
            return encodeString(current)
        elseif valueType ~= "table" then
            error("cannot encode Lua type '" .. valueType .. "' as JSON", 0)
        end

        if activeTables[current] then
            error("cannot encode a circular table as JSON", 0)
        end
        activeTables[current] = true

        local result = {}
        if isArray(current) then
            for index = 1, #current do
                result[#result + 1] = encodeValue(current[index])
            end
            activeTables[current] = nil
            return "[" .. table.concat(result, ",") .. "]"
        end

        local keys = {}
        for key in pairs(current) do
            if type(key) ~= "string" then
                error("JSON object keys must be strings", 0)
            end
            keys[#keys + 1] = key
        end
        table.sort(keys)

        for _, key in ipairs(keys) do
            result[#result + 1] =
                encodeString(key) .. ":" .. encodeValue(current[key])
        end

        activeTables[current] = nil
        return "{" .. table.concat(result, ",") .. "}"
    end

    return encodeValue(value)
end

function json.array(values)
    return setmetatable(values or {}, arrayMarker)
end

function json.is_array(value)
    return type(value) == "table" and
        getmetatable(value) == arrayMarker
end

json.decode = decode
json.encode = encode

return json
